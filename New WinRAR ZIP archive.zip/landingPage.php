<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medidas|Nutricense</title>
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/general.css">
</head>

<body>
    <?php session_start();?>



<ul id="navbar">
    <li>

        <div class="contenedorLogo">
            <a href="index.php">
                <img class="logo" src="media/332389118_1293787391492551_1282763326629383693_n.jpg" alt="Logo de la empresa Nutricense que es una letra n con una hoja de arbol" srcset="">
            </a>
        </div>

    </li>
    <h1>NUTRICENSE</h1>
    <li>
        <button><a href="includes/logout.inc.php">Desloguearse</a></button>
    </li>
</ul>


<div class="contenedorMedidas">
    <h2>MEDIDAS ANTROPOMETRICAS</h2>
    <h3>Llene todos los campos</h3>


    <div class="itemAntro" id="nombreCompleto">
        <label for="nombre">Nombre completo</label>
        <input type="text" name="nombre" id="nombreCompletoInput">
    </div>
    
    <div class="contenedorSecundario">

        <div class="contenedorInterno">

            <div class="itemAntro">
                <label for="sexo">Sexo</label>
                <select name="sexo" id="sexo">
                    <option value="x" disabled selected>Seleccione una opcion</option>
                    <option value="m">Mujer</option>
                    <option value="h">Hombre</option>
                </select>
            </div>
            <div class="itemAntro">
                <label for="edad">Edad (años)</label>
                <input type="text" name="edad" id="edad">
            </div>
            <div class="itemAntro">
                <label for="peso">Peso actual (kgs)</label>
                <input type="text" name="peso" id="peso">
            </div>
            
            <div class="itemAntro">
                <label for="estatura">Talla en centimetros (cms)</label>
                <input type="text" name="estatura" id="estatura">
            </div>



        
        </div>
        <div class="contenedorInterno">


            <div class="itemAntro">
                <label for="circunferenciaMunneca">Circunferencia de la muñeca (cms)</label>
                <input type="text" name="circunferenciaMunneca" id="circunferenciaMunneca">
            </div>

            <div class="itemAntro">
                <label for="composicionTamanno">Composicion corporal: <span id=""></span></label>
                <input type="text" name="composicionTamanno" id="composicionTamanno" disabled>
                <!--<p id="composicionCorporal"></p>-->
            </div>

            <div class="itemAntro">
                <label for="grasaCorporal">Porcentaje de grasa corporal (%)</label>
                <input type="text" name="grasaCorporal" id="grasaCorporal">
            </div>
            <div class="itemAntro">
                <label for="actividadFisica">Actividad física</label>
                <select name="actividadFisica" id="actividadFisica">
                    <option value="" disabled selected>Seleccione una opcion</option>
                    <option value="1">Encamado ventilacion</option>
                    <option value="2">Encamado</option>
                    <option value="3">Sedentario</option>
                    <option value="4">Actividad fisica</option>
                </select>
            </div>

        </div>



    </div>

    <button id="botonPesoIdeal" class="boton2">Calcular peso ideal</button>


</div>

<section id="resultadosAntro">
<h2>EVALUACION ANTROPOMETRICA</h2>
    <div class="contenedorSecundario">
        <div class="contenedorInterno">
        
                 <!--<div>
                    <h4>Masa grasa</h4>
                    <p id="masaGrasa"></p>
                </div>
        
                <div>
                    <h4>Masa libre de grasa</h4>
                    <p id="masaLibreGrasa"></p>
                </div>
        
               <div>
                   <h4>Composicion corporal: <span id="composicionTamanno"></span></h4>
                    <p id="composicionCorporal"></p>
                </div>
        
                <div>
                    <h4>IMC: <span id="valorIMC"></span></h4>
                    <p id="estadoIMC"></p>
                </div>
                <div>
                    <h4>Peso ideal (ADA): <span id="valorPIdealAda"></span></h4>
                </div>
                <div>
                    <h4>Peso ideal ADA -10%: <span id="idealAdaMas10"></span> kgs</h4>
                </div>
                <div>
                    <h4>Peso ideal ADA +10%: <span id="idealAdaMenos10"></span> kgs</h4>
                </div>
                <div>
                    <h4>Peso ajustado (ADA): <span id="valorPAjustadoAda"></span></h4>
                </div>
                <div>
                    <h4>Peso ajustado ADA -10%: <span id="ajustadoAdaMas10"></span> kgs</h4>
                </div>
                <div>
                    <h4>Peso ajustado ADA +10%: <span id="ajustadoAdaMenos10"></span> kgs</h4>
                </div>
                <div>
                    <h4>Peso ideal (IMC): <span id="valorPIdealIMC"></span> kgs</h4>
                </div>
                <div>
                    <h4>Peso ajustado (IMC): <span id="valorPAjustadoIMC"></span> kgs</h4>
                </div>-->
        </div>
        <div class="contenedorInterno">

        </div>
    </div>

        <table id="tablaResultados">
            <tbody>
<!--
                <tr>
                    <td class="td1" >:</td>
                    <td class="td2" id=""></td>
                    <td class="td3"></td>
                </tr>
-->
                <tr>
                    <td class="td1" >Nombre del cliente:</td>
                    <td class="td2" id="nombreClienteimp"></td>
                    <td class="td3"></td>
                </tr>
                                
                <tr>
                    <td class="td1" >Edad:</td>
                    <td class="td2" id="edadClienteimp"></td>
                    <td class="td3">años</td>
                </tr>
                <tr>
                    <td class="td1" >Peso:</td>
                    <td class="td2" id="pesoClienteimp"></td>
                    <td class="td3">kgs</td>
                </tr>
                <tr>
                    <td class="td1" >Estatura:</td>
                    <td class="td2" id="estaturaImp"></td>
                    <td class="td3">mts</td>
                </tr>
                     
                <tr>
                    <td class="td1" >Composicion corporal:</td>
                    <td class="td2" id="composicionImp"></td>
                    <td class="td3"></td>
                </tr>
                                                
                <tr>
                    <td class="td1" >Grasa corporal:</td>
                    <td class="td2" id="grasaImp"></td>
                    <td class="td3">%</td>
                </tr>
                                                


                <tr>
                    <td class="td1" >Masa grasa:</td>
                    <td class="td2" id="masaGrasaImp"></td>
                    <td class="td3"></td>
                </tr>
                <tr>
                    <td class="td1">IMC:</td>
                    <td class="td2" id="IMCImp"></td>
                    <td class="td3" id="estadoIMCImp"></td>
                </tr>
                <tr>
                    <td class="td1">Masa libre de grasa:</td>
                    <td class="td2" id="masaLibreGrasaImp"></td>
                    <td class="td3"></td>
                </tr>
                <tr>
                    <td class="td1">Peso ideal (ADA):</td>
                    <td class="td2" id="pesoIdealAdaImp"></td>
                    <td class="td3"></td>
                </tr>
                <tr>
                    <td class="td1" >Peso ideal ADA -10%:</td>
                    <td class="td2" id="idealAdaMas10Imp"></td>
                    <td class="td3">kgs</td>
                </tr>
                <tr>
                    <td class="td1">Peso ideal ADA +10%:</td>
                    <td class="td2" id="idealAdaMenos10Imp"></td>
                    <td class="td3">kgs</td>
                </tr>
                <tr>
                    <td class="td1">Peso ajustado (ADA):</td>
                    <td class="td2" id="pesoAjustadoAdaImp"></td>
                    <td class="td3">kgs</td>
                </tr>
                <tr>
                    <td class="td1">Peso ajustado ADA -10%:</td>
                    <td class="td2" id="ajustadoAdaMas10Imp"></td>
                    <td class="td3">kgs</td>
                </tr>
                <tr>
                    <td class="td1">Peso ajustado ADA +10%:</td>
                    <td class="td2" id="ajustadoAdaMenos10Imp"></td>
                    <td class="td3">kgs</td>
                </tr>
                <tr>
                    <td class="td1">Peso ideal (IMC):</td>
                    <td class="td2" id="pesoIdealIMCImp"></td>
                    <td class="td3">kgs</td>
                </tr>
                <tr>
                    <td class="td1">Peso ajustado (IMC):</td>
                    <td class="td2" id="pesoAjustadoIMCImp"></td>
                    <td class="td3">kgs</td>
                </tr>
                <tr>
                    <td class="td1">TMB (Mifflin):</td>
                    <td class="td2" id="tmbMifImp"></td>
                    <td class="td3"></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>


            </tbody>
        </table>
       


</section>


</div>
    <div class="sectionContainer">

        <section id="inputsAntropometricas">
            <form action="">

                
    </div>
    <div>

    </div>
    <div>

    </div>
    <div>
       
    </div>
    <div>

    </div>
    <div>

    </div>

    <div>
 
    </div>


    </form>


    </section>


    <section id="resultadosAntropometricas">


        


    </section>

    <section id="seccionIMC">


    </section>

    <section id="pesoIdeal">



    </section>
    </div>


    <script src="js/landingPage.js"></script>
</body>

</html>